<?php
session_start();
require_once 'php/config.php';

if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    header("location: login.php");
    exit;
}

$search_query = '';
$recipes = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_query = mysqli_real_escape_string($link, $_GET['search']);
    
    $sql = "SELECT * FROM recipes WHERE title LIKE '%$search_query%' OR description LIKE '%$search_query%'";
    $result = mysqli_query($link, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $recipes[] = $row;
        }
    }
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - 1000 και 1 Συνταγές</title>
    <link rel="stylesheet" href="src/style/style.css">
    <link rel="stylesheet" href="src/style/bootstrap.min.css">
</head>
<body class="body">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact us</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Recipes
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="upload_recipe.php">Upload a recipe</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="Find_a_recipe.php">Recipes</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Profile
                        </a>
                        <ul class="dropdown-menu">
                            <?php if (isset($_SESSION['username'])): ?>
                                <li><a class="dropdown-item" href="profile.php"><?php echo htmlspecialchars($_SESSION['username']); ?></a></li>
                                <li><a class="dropdown-item" href="logout.php">Log out</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login.php">Login</a></li>
                                <li><a class="dropdown-item" href="register.php">Register</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header>
        <div class="p-5 text-center bg-custom" style="background-color: #F6FDC3;">
            <h2>Αποτελέσματα Αναζήτησης</h2>
            <p>Δείτε τις συνταγές που βρέθηκαν για: <?php echo htmlspecialchars($search_query); ?></p>
        </div>
    </header>

    <div class="container mt-4">
        <?php if (!empty($recipes)): ?>
            <div class="list-group">
                <?php foreach ($recipes as $recipe): ?>
                    <a href="recipe_detail.php?id=<?php echo $recipe['id']; ?>" class="list-group-item list-group-item-action">
                        <h5 class="mb-1"><?php echo htmlspecialchars($recipe['title']); ?></h5>
                        <p class="mb-1"><?php echo htmlspecialchars($recipe['description']); ?></p>
                        <small>Συστατικά: <?php echo htmlspecialchars($recipe['ingredients']); ?></small>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted">Δεν βρέθηκαν συνταγές για τον όρο: <?php echo htmlspecialchars($search_query); ?></p>
        <?php endif; ?>
        <a href="Find_a_recipe.php" class="btn btn-primary mt-3">Επιστροφή στην Αναζήτηση</a>
    </div>

    <footer>
        <div class="container" style="background-color: #FF8080;">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Τηλέφωνο: +30 1234567890 | Ηλεκτρονικό Ταχυδρομείο: info@example.com</p>
                                <p class="text-muted">Κεντρικά Γραφεία: Οδός Παράδεισος 123, Αθήνα, 12345</p>
                                <p class="text-muted">Καταστήματα με Υλικά Μαγειρικής: Οδός Αρωματική 456, Θεσσαλονίκη, 54321</p>
                                <p class="text-muted">Καταστήματα με Μαγειρεμένες Συνταγές: Οδός Γευστική 789, Πάτρα, 67890</p>
                                <p class="text-muted">Καταστήματα με Βιβλία Συνταγών: Οδός Γνώσης 101, Ηράκλειο, 98765</p>
                                <p class="text-muted">Σχολές Μαγειρικής του Ομίλου "1000 και 1 Γεύσεις": Οδός Εκπαίδευσης 202, Λάρισα, 13579</p>
                            </div>
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Ιδιοκτήτης: Νικόλαος Παπαδόπουλος | Τηλέφωνο: +30 2101234567 | Ηλεκτρονικό Ταχυδρομείο: nikos@example.com</p>
                                <p class="text-muted">Λογιστήριο: Μαρία Αντωνίου | Τηλέφωνο: +30 2102345678 | Ηλεκτρονικό Ταχυδρομείο: maria@example.com</p>
                                <p class="text-muted">Εξυπηρέτηση Πελατών: Αλέξης Γεωργίου | Τηλέφωνο: +30 2103456789 | Ηλεκτρονικό Ταχυδρομείο: alex@example.com</p>
                                <p class="text-muted">Γραμματεία: Ελένη Κωνσταντινίδου | Τηλέφωνο: +30 2104567890 | Ηλεκτρονικό Ταχυδρομείο: eleni@example.com</p>
                                <p class="text-muted">Αντιπρόεδρος: Σοφία Παπαδοπούλου | Τηλέφωνο: +30 2105678901 | Ηλεκτρονικό Ταχυδρομείο: sofia@example.com</p>
                            </div>
                        </div>
                    </div>
                    <p class="text-muted">Legal Rights &copy; 2024 | All rights reserved</p>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://unpkg.com/@popperjs/core@2/dist/umd/popper.js"></script>
    <script src="src/script/bootstrap.min.js"></script>
    
</body>
</html>
