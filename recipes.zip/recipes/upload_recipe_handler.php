<?php
session_start();
require_once 'php/config.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Πρέπει να συνδεθείτε πρώτα για να ανεβάσετε μια συνταγή.";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = mysqli_real_escape_string($link, $_POST['title']);
    $description = mysqli_real_escape_string($link, $_POST['description']);
    $ingredients = mysqli_real_escape_string($link, $_POST['ingredients']);
    $instructions = mysqli_real_escape_string($link, $_POST['instructions']);
    $user_id = $_SESSION['user_id'];
    $image = '';

    if (isset($_POST['image']) && !empty($_POST['image'])) {
        $image = mysqli_real_escape_string($link, $_POST['image']);
    }

    $sql = "INSERT INTO recipes (user_id, title, description, ingredients, instructions, image) VALUES (?, ?, ?, ?, ?, ?)";
    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "isssss", $user_id, $title, $description, $ingredients, $instructions, $image);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['message'] = "Η συνταγή σας ανέβηκε με επιτυχία!";
        } else {
            $_SESSION['message'] = "Κάτι πήγε στραβά. Παρακαλώ δοκιμάστε ξανά.";
        }
        mysqli_stmt_close($stmt);
    }

    mysqli_close($link);

    header("Location: Find_a_recipe.php");
    exit();
} else {
    header("Location: upload_recipe.php");
    exit();
}