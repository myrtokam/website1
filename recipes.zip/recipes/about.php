<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="src/style/bootstrap.min.css">
    <link rel="stylesheet" href="src/style/style.css">
</head>

<body class="body">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Αρχική</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact us</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Recipes
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="upload_recipe.php">Upload a recipe</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="Find_a_recipe.php">Recipes</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Profile
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="logout.php">Log out</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="create_profile.php">Create profile</a></li>
                            <li><a class="dropdown-item" href="profile.php">Others profile</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <header>
        <div class="p-5 text-center bg-custom" style="background-color: #F6FDC3;">
            <h2>Σχετικά με εμάς</h2>
            <p>Μάθετε περισσότερα για την ομάδα μας</p>
        </div>
    </header>
    <div class="container-fluid" style="background-color: #F6FDC3;">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h3>Η Αποστολή μας</h3>
                <p>Καλωσορίσατε στον κόσμο των "1000 και 1 Συνταγές", ένα ζωντανό κοινωνικό δίκτυο αφιερωμένο στη
                    σύνδεση των λάτρεων της μαγειρικής από όλο τον κόσμο. Η αποστολή μας είναι να δημιουργήσουμε έναν
                    χώρο όπου οι άνθρωποι μπορούν να μοιράζονται τις μαγειρικές τους δημιουργίες, να ανακαλύπτουν νέες
                    συνταγές και να συνδέονται με άλλους που μοιράζονται το πάθος τους για τη μαγειρική.</p>

                <h3>Η Ιστορία μας</h3>
                <p>Οι "1000 και 1 Συνταγές" ιδρύθηκαν από μια ομάδα φίλων που συνδέθηκαν μέσω της αγάπης τους για το
                    φαγητό και τη μαγειρική. Συνειδητοποιήσαμε ότι, ενώ υπάρχουν πολλοί ιστότοποι συνταγών, λίγοι
                    προσφέρουν την αίσθηση της κοινότητας και της προσωπικής σύνδεσης που αναζητούσαμε. Γι' αυτό
                    δημιουργήσαμε αυτήν την πλατφόρμα - για να ενθαρρύνουμε μια κοινότητα όπου οι λάτρεις του φαγητού
                    μπορούν όχι μόνο να μοιράζονται τις συνταγές τους αλλά και να αλληλεπιδρούν και να χτίζουν σχέσεις.
                </p>

                <h3>Γνωρίστε την Ομάδα</h3>
                <p>Η ομάδα μας αποτελείται από λάτρεις της μαγειρικής, σεφ και τεχνολογικά καταρτισμένα άτομα που
                    εργάζονται ακούραστα για να διατηρήσουν και να βελτιώσουν αυτήν την πλατφόρμα. Δεσμευόμαστε να σας
                    προσφέρουμε την καλύτερη δυνατή εμπειρία χρήσης και είμαστε πάντα εδώ για να βοηθήσουμε με τυχόν
                    ερωτήσεις ή προβλήματα που μπορεί να έχετε.</p>


                <h3>Γίνετε Μέλος</h3>
                <p>Σας προσκαλούμε να γίνετε μέλος της κοινότητάς μας, να μοιραστείτε τις συνταγές σας και να
                    ανακαλύψετε νέες. Είτε είστε έμπειρος σεφ είτε μόλις ξεκινάτε το γαστρονομικό σας ταξίδι, οι "1000
                    και 1 Συνταγές" είναι το ιδανικό μέρος για να εξερευνήσετε τον κόσμο της μαγειρικής.</p>
            </div>
        </div>
    </div>
    <br><br>
    <footer>
        <div class="container" style="background-color: #FF8080;">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Τηλέφωνο: +30 1234567890 | Ηλεκτρονικό Ταχυδρομείο:
                                    info@example.com</p>
                                <p class="text-muted">Κεντρικά Γραφεία: Οδός Παράδεισος 123, Αθήνα, 12345</p>
                                <p class="text-muted">Καταστήματα με Υλικά Μαγειρικής: Οδός Αρωματική 456, Θεσσαλονίκη,
                                    54321</p>
                                <p class="text-muted">Καταστήματα με Μαγειρεμένες Συνταγές: Οδός Γευστική 789, Πάτρα,
                                    67890</p>
                                <p class="text-muted">Καταστήματα με Βιβλία Συνταγών: Οδός Γνώσης 101, Ηράκλειο, 98765
                                </p>
                                <p class="text-muted">Σχολές Μαγειρικής του Ομίλου "1000 και 1 Γεύσεις": Οδός
                                    Εκπαίδευσης 202, Λάρισα, 13579</p>
                            </div>
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Ιδιοκτήτης: Νικόλαος Παπαδόπουλος | Τηλέφωνο: +30 2101234567 |
                                    Ηλεκτρονικό Ταχυδρομείο: nikos@example.com</p>
                                <p class="text-muted">Λογιστήριο: Μαρία Αντωνίου | Τηλέφωνο: +30 2102345678 |
                                    Ηλεκτρονικό Ταχυδρομείο: maria@example.com</p>
                                <p class="text-muted">Εξυπηρέτηση Πελατών: Αλέξης Γεωργίου | Τηλέφωνο: +30 2103456789 |
                                    Ηλεκτρονικό Ταχυδρομείο: alex@example.com</p>
                                <p class="text-muted">Γραμματεία: Ελένη Κωνσταντινίδου | Τηλέφωνο: +30 2104567890 |
                                    Ηλεκτρονικό Ταχυδρομείο: eleni@example.com</p>
                                <p class="text-muted">Αντιπρόεδρος: Σοφία Παπαδοπούλου | Τηλέφωνο: +30 2105678901 |
                                    Ηλεκτρονικό Ταχυδρομείο: sofia@example.com</p>
                            </div>
                        </div>
                    </div>
                    <p class="text-muted">Legal Rights &copy; 2024 | All rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

</body>
<script src="https://unpkg.com/@popperjs/core@2/dist/umd/popper.js"></script>
<script src="src/script/bootstrap.min.js"></script>

</html>