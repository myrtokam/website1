<?php
session_start();
require_once 'php/config.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    $errors = [];

    if (empty($username)) {
        $errors[] = 'Το όνομα χρήστη είναι υποχρεωτικό.';
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Παρακαλώ εισάγετε ένα έγκυρο email.';
    }

    if (empty($password)) {
        $errors[] = 'Ο κωδικός είναι υποχρεωτικός.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Οι κωδικοί δεν ταιριάζουν.';
    }

    if (empty($errors)) {
        $query = "SELECT id FROM users WHERE username = ? OR email = ?";
        if ($stmt = $link->prepare($query)) {
            $stmt->bind_param('ss', $username, $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $errors[] = 'Το όνομα χρήστη ή το email χρησιμοποιείται ήδη.';
            }
            $stmt->close();
        } else {
            $errors[] = 'Σφάλμα κατά τον έλεγχο των δεδομένων.';
        }
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";

        if ($stmt = $link->prepare($query)) {
            $stmt->bind_param('sss', $username, $email, $hashed_password);
            if ($stmt->execute()) {
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['username'] = $username;
                header('Location: index.php');
                exit();
            } else {
                $errors[] = 'Σφάλμα κατά την εγγραφή του χρήστη.';
            }
            $stmt->close();
        } else {
            $errors[] = 'Σφάλμα κατά την προετοιμασία του αιτήματος.';
        }
    }

    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: register.php');
        exit();
    }
} else {
    header('Location: register.php');
    exit();
}