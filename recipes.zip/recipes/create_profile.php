<?php
session_start();
$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : [];
unset($_SESSION['errors']);
?>
<!DOCTYPE html>
<html lang="el">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Εγγραφή</title>
    <link rel="stylesheet" href="src/style/bootstrap.min.css">
    <link rel="stylesheet" href="src/style/style.css">
</head>

<body class="body">
<nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Αρχική</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact us</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Recipes
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="upload_recipe.php">Upload a recipe</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="Find_a_recipe.php">Recipes</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Profile
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="login.php">Login</a></li>
                            <li><a class="dropdown-item" href="logout.php">Log out</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="create_profile.php">Create profile</a></li>
                            <li><a class="dropdown-item" href="profile.php">Others profile</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header>
        <div class="p-5 text-center bg-custom" style="background-color: #F6FDC3;">
            <h2>Εγγραφή</h2>
            <p>Δημιουργήστε έναν νέο λογαριασμό</p>
        </div>
    </header>

    <div class="container mt-3">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3>Φόρμα Εγγραφής</h3>
                <form action="register_process.php" method="post">
                    <div class="mb-3">
                        <label for="username" class="form-label">Όνομα χρήστη</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Ηλεκτρονικό Ταχυδρομείο</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Κωδικός</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Επιβεβαίωση Κωδικού</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Εγγραφή</button>
                </form>
                <br>
                <p>Έχετε ήδη λογαριασμό; <a href="login.php">Συνδεθείτε εδώ</a>.</p>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container" style="background-color: #FF8080;">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Τηλέφωνο: +30 1234567890 | Ηλεκτρονικό Ταχυδρομείο:
                                    info@example.com</p>
                                <p class="text-muted">Κεντρικά Γραφεία: Οδός Παράδεισος 123, Αθήνα, 12345</p>
                            </div>
                            <div class="col-sm-6" style="text-align: center;">
                                <p class="text-muted">Ιδιοκτήτης: Νικόλαος Παπαδόπουλος | Τηλέφωνο: +30 2101234567 |
                                    Ηλεκτρονικό Ταχυδρομείο: nikos@example.com</p>
                            </div>
                        </div>
                    </div>
                    <p class="text-muted">Legal Rights &copy; 2024 | All rights reserved</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://unpkg.com/@popperjs/core@2/dist/umd/popper.js"></script>
    <script src="src/script/bootstrap.min.js"></script>
    
</body>

</html>
